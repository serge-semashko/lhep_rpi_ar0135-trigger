#!/bin/bash
python fr_serv.py
