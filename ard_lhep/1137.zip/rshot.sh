rm  *.jpg
rm  *.png
python3 brightness_cycled.py  -v --preview-width 1280 -f 1.cfg
