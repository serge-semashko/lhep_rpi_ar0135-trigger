sudo python3 brightness_cycled.py
