service memcached start
