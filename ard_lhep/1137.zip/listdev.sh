v4l2-ctl --list-devices
